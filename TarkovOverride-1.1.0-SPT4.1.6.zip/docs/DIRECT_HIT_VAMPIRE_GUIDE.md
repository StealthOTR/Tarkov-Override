# Tarkov Override 1.1.0 — New Features

Close the game before updating. Merge the ZIP's BepInEx folder into SPT and replace the existing plugin DLL. Your settings and JSON hotkeys are preserved.

## Direct Hit Mode

Find Direct hit mode in Rage Aim. Turn it on to reveal the body-part dropdown and extra controls. Choices are Head, Thorax, Stomach, Left Arm, Right Arm, Left Leg and Right Leg. Turn the feature off to hide the dropdown; your choice is remembered.

Direct Hit works independently of the aim master and does not move your view. It uses its own range (300 m by default), FOV radius (30 degrees) and visibility setting, together with the Rage profile's enemy-type/group/exclusion filters and individually ignored enemies. Disable Direct hit visible only if you want direct application through cover.

Fire normally: eligible bullets are applied to the selected part through the native hit/damage callback. Ammunition is consumed normally. If no target qualifies, the shot behaves normally. The selection considers up to four enemies nearest the crosshair and uses at most four visibility rays per projectile; it does not continuously scan the scene.

Shotgun pellets can each qualify. Grenades, rockets, flares, child fragments and explosive-ammo components are excluded. Damage comes from the ammunition: choosing Head is not an automatic instant-kill toggle. Native body-hit/armour handling is invoked, but physical travel and interception are bypassed, so armour outcomes may differ from ordinary projectile travel.

Direct Hit's damage part is separate from Rage aiming's Strict Head setting. The existing aim marker belongs to the aiming system, not a separate Direct Hit indicator.

## Vampire Mode

Find Vampire mode in Player. Defaults:

- Damage healing: 20% of actual enemy health lost.
- Kill healing bonus: 10 HP.
- Maximum healing per hit: 100 HP, including the bonus.

Set the percentage to zero for kill-only healing, or the bonus to zero for damage-only healing. Only damage attributed to your player against living AI qualifies. Armour-absorbed damage and overkill do not count. Recursive limb damage is counted once. Ordinary attributed damage and Direct Hit can both generate healing.

Healing is applied to your most injured living body parts, up to their current maxima. It cannot revive destroyed parts or a dead player, and does not remove bleeding, fractures or other effects. Healing already received remains normal health.

## Defaults and resets

Both toggles start off and reset on death, raid/player changes, Panic and shutdown. Numeric preferences and body-part choice remain saved. Disabling/resetting Vampire discards pending healing. No extra JSON hotkeys, automatic firing or firing restrictions were added.

## Testing

Build, body-part/healing policy and hook-scope checks passed. Live damage/kill attribution, armour behaviour, shotgun handling and healing still require a raid test. Try each feature individually, then together, and verify Panic and the next raid reset them. Other combat mods may change the native results.

Grenade Magnet remains planned and is not included in this update.
