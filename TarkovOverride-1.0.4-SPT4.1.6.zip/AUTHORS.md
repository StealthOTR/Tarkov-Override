# Credits

Tarkov Override

Author: StealthOTR

Designed for solo SPT 4.1.6 using its bundled BepInEx and Harmony environment. Third-party game/framework binaries are not included in the source package.
