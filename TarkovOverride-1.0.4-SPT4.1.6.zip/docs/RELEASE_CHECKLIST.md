# Publication checklist

The 1.0.0 release package is prepared; this checklist does not imply it has been published or approved by a website.

- Complete a clean-install and upgrade test.
- Test representative maps and a full raid/save/restart cycle, including death and normal extraction.
- Check Panic/reset, no-clip restoration, Demigod save normalization and generated configs.
- Record performance with common and busy feature combinations.
- Capture current screenshots showing the Tarkov Override header and StealthOTR credit.
- Identify the target website and review its current submission/content rules.
- Select distribution/source licensing terms and add the corresponding licence file.
- Review the description, known limitations and support contact before submission.

Vampire Mode remains planned and is not advertised as an implemented feature. No game DLLs or installed user configs should be uploaded.
