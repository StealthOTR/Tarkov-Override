# Rage ADS movement sway — 1.0.4

- Inspected MotionEffector.Process and WalkEffector.Process in the installed game. Motion uses a scalar movement intensity and vector turn sway factors; Walk passes separate normal and overweight amplitudes to ProcessRaw.
- New wrappers filter those amplitude inputs only for the exact MotionReact/Walk instances belonging to the living local player's held firearm, with both the Rage master and actual ADS states active. No target lock is required.
- The overweight branch condition, native calls and animation clocks are retained. No settings/spring/template fields are written by the filtering wrappers. Normal behaviour resumes by scope alone, with no persistent override to restore.
- Ten isolated native-IL/default-scope checks passed: expected scalar/vector replacement counts for both real method bodies, unchanged field stores/native processing calls, and normal amplitude with no local owner. No game methods were executed.
- Built against SPT 4.1.6; the existing facade warning remains. New toggle defaults true but only acts inside enabled Rage ADS. No JSON bindings or firing controls were added.

Live ADS movement, transition settling and interaction with other animation mods require a raid test. Existing spring motion may settle briefly; recoil, breath/injury effects and unrelated animations are not removed. Prior validation follows.

---
# Rage tracking and optional prediction — 1.0.3

- User clarified head-to-body movement occurs on the same enemy while ADS, and explicitly declined firing restrictions.
- Strict Head now forces the selected point to Head for every saved Target bone choice. Inactive point/fallback controls are disabled in the Rage UI. Invalid final body-point selection is rejected without altering firing.
- Head tracking caches a model-skeleton head transform; it no longer alternates with collider centres. A fixed original-head transform is the fallback if model-head resolution fails.
- Inspected native MovementContext rotation and LookDirection calculation. Rage instant turns now use that native direction instead of rendered camera forward, avoiding a potential ADS feedback mismatch. This is not proof of the reported live cause.
- Added analytic, bounded movement/drop estimates using native target velocity and Weapon.TotalVelocity. Inspected TotalVelocity: it combines current ammo speed and weapon/mod velocity factor. No drag/zeroing equivalence is claimed.
- Eighteen pure checks passed for forced-head policy, bone-name filtering, stationary/moving intercepts, gravity sign, impossible intercepts, time limits and invalid inputs.
- Compiled-code checks confirm the native look reference and absence of firing-control calls in the new tracking/solution methods. No trigger hooks were introduced.
- Built against SPT 4.1.6; existing facade warning remains. No installed game/config files were modified.

Live head tracking, ADS convergence and compensation accuracy remain pending a raid test. Prediction/drop default off to isolate the tracking change first. Prior validation follows.

---
# Live head coordinates — 1.0.2

- User reported the selected marker itself remained at upper chest while ADS with both magnified and unmagnified sights, despite Strict Head Targeting. Installed log/config confirmed v1.0.1 and the strict option enabled. This narrows the issue beyond fallback policy; the exact live coordinate discrepancy was not captured.
- Inspected BifacialTransform.position: it can return accumulated or imitation positions instead of Original.position. Head targeting now requires the original animated head transform, which the native head animation also uses.
- Physics bounds are no longer used for head targeting. A capsule/sphere/box centre is transformed through its live transform and accepted only beneath the original head hierarchy and within 22 cm of the head bone. Otherwise the live head bone wins. No fixed standing-height head guess remains.
- Nine resolver checks passed: stale chest-height rejection, adjacent head centre, crouch/prone coordinates, missing live head, invalid vectors and safe bone-only resolution. Twelve fallback-policy checks also passed.
- ScreenPoint now uses normalized viewport coordinates and the camera rect, avoiding an assumption that render-texture pixels equal display pixels.
- Built against installed SPT 4.1.6. Native GUI rendering, live bone placement, ADS convergence and shot impacts still need an in-raid check. The existing facade warning remains.

Prior validation follows.

---
# Head targeting correction — 1.0.1

- Installed user configuration was inspected read-only: Rage selected Head with Aim point fallback and visibility enabled. The existing candidate loop could choose chest/pelvis when Head failed its checks.
- Added default-on Strict head targeting to Rage Aim. It restricts Head selection to one candidate point while preserving the optional legacy fallback policy and nearest-to-crosshair/body-point choices.
- Twelve policy regression checks passed: blocked-head rejection despite visible chest/pelvis, selected-head preference, intentional fallback, disabled fallback, visibility-off policy and other target modes.
- Head aiming uses the enabled native Head body-part collider centre when available, then the existing bone/root fallback. Visibility additionally accepts native registered player colliders and BodyPartCollider ownership.
- Tracking status reports the actual selected point and labels fallback. Existing config paths/GUID and JSON bindings are unchanged; the new strict option defaults on without rewriting installed settings.
- Built against installed SPT 4.1.6 assemblies. The existing facade warning remains.

This establishes selection policy, not live ballistic accuracy. Head placement across poses, visibility and actual shot impacts require a raid test. Prior validation follows.

---
# Release branding and packaging — 1.0.0

- Built with Tarkov Override BepInEx metadata and assembly title/product/version. Author/company credit is StealthOTR.
- Header title and author are drawn in DrawCompactContents before tab buttons and scroll columns. They do not depend on the selected tab. Title, credit and version have separate non-overlapping rectangles within the existing header.
- Plugin GUID, DLL path and configuration locations are preserved. The package does not include installed .cfg or config.json replacements.
- Gameplay implementation is unchanged from 0.8.3. This branding/package update does not add live-game verification or website approval. Publication checks are listed separately.

Prior validation follows.

---
# No-clip controller compatibility — 0.8.3

- Confirmed in the installed game that SimpleCharacterController.get_detectCollisions and set_detectCollisions unconditionally throw NotSupportedException.
- Verified the supported public IsMoveIgnored, isEnabled and GetCollider APIs, and that Move returns early when IsMoveIgnored is true.
- Replaced unconditional collision-property access with a controller-state helper. SimpleCharacterController never uses detectCollisions. Other backends preserve supported collision state, with a one-time NotSupportedException fallback.
- Capture completes before activation. Restore treats each property independently, so one failure does not skip the remaining state. Controller changes during play trigger restoration and recapture.
- Eleven regression checks passed against the exact helper source using simulated controller/collider backends: unsupported accesses avoided, movement suspension, repeated application, restoration of preexisting states, supported alternate backend, one-time fallback and partial restoration failure.
- Built against the installed SPT 4.1.6 assemblies. Existing facade warning remains. No installed files or user configuration were changed.

Live no-clip movement and collision restoration require a raid test. Prior validation follows.

---
# Manual airdrop validation — 0.8.2

- Built against installed SPT 4.1.6/BepInEx assemblies; the existing netstandard facade warning remains.
- Inspected GameWorld.InitAirdrop: the base body is empty, but it is virtual and ClientGameWorld overrides it with the actual point selection, AirPlane pool acquisition and InitSyncObject path. The plugin requires ClientGameWorld and its initialized server airdrop manager before making that call.
- The request uses the same null loot-template/default-position arguments as the native normal airdrop event. Server plane logic retains native crate creation and loot loading.
- Checks require active map drop points and CanSummonAirdrop, a living local player, no requested extraction, and an elapsed 60-second button cooldown.
- Availability checks are in the Misc button UI/action only; no new Update/LateUpdate/physics polling was added. The removed grenade predictor remains absent.
- Vampire Mode is recorded as planned only. No installed game or configuration files were modified.

Live arrival, loot generation and pickup remain pending an in-raid test. Prior validation follows.

---
# Grenade-preview removal — 0.8.1

- Removed the trajectory simulator, buffers, grenade-transform reads, update scheduling, drawing, settings and visible shortcut.
- Compiled-code inspection confirms no prediction methods, SphereCastNonAlloc calls or trajectory configuration binding remain.
- Thirty-one hotkey checks passed, including ignoring a conflicting or invalid legacy ToggleGrenadePreview value. The installed JSON loads with 29 active actions; no installed files were changed.
- Built against the installed SPT 4.1.6 assemblies. The existing netstandard facade warning remains.

Live frame-time improvement requires an in-raid check. Earlier validation records below describe previous versions, including the now-removed feature.

---
# Equipment and awareness validation — 0.8.0

- Built against installed SPT 4.1.6 and BepInEx assemblies. The pre-existing Newtonsoft.Json/netstandard facade warning remains.
- Nineteen native-IL and fallback checks passed in an isolated process. The compiled medical, weight and interaction transpilers were invoked on the real game method bodies without executing those game methods: one medical resource write in RegularUpdate and four in Residue are replaced; one physical weight input is filtered; three local interaction validations and the world query distance are wrapped. Default-off/no-owner guards and fire-rate/heat math were also checked.
- Twenty-nine hotkey/input checks passed against the updated Hotkeys.cs. The installed user JSON and example deserialize/parse with all 30 actions; the installed file hash is unchanged. New optional actions default to None.
- Inspected native MedEffectHelper.RemoveItem, which handles both stack splitting and whole-item removal. Its prefix protects only medical items owned by the living local player's inventory controller. Food/drink and other players use native consumption.
- Repair traverses equipped roots and fitted slots, not cargo grids. Optional factory-maximum repair preserves already higher custom maxima.
- Automatic fire uses a cached shot interval in this game version. The update handles that interval as well as the FireRate/SingleFireRate getters; native heat multipliers remain and shared templates are not edited.
- Native grenade throw uses an impulse. Preview follows the inspected strength/stamina formula and prefab mass. Collision prediction is spread across frames, at most eight segment casts per frame, with a fixed hit buffer and no grenade spawning or native throw invocation.
- Nearby alerts check living AI four times per second and use a re-entry margin/cooldown for optional tones. They do not depend on enemy ESP being enabled.
- Extraction inspection confirmed separate InfiltrationMatch checks for PMC and scav points, requirement callbacks and an existing raid-end scenario subscribed to all normal exits. The update handles local eligibility/requirements, normal point availability and individual-mode timing; secret/transit/scripted zones are excluded. Snapshot restoration cancels the local override extraction and restores captured status/mode/activation/start time.
- New toggles join the existing raid/player/Panic/shutdown reset path. New optional controls use the same JSON text-entry mechanism, dark fields and tooltip path.

Live raid validation is pending for repairs and saving, medical treatment, movement, interaction reach, perceived fire rate, grenade accuracy, alert rendering/audio and conditional exits. Extraction restoration uses captured state; it does not reconstruct world-script schedule changes while the override was active. No files were installed into SPT during preparation. Prior validation follows.

---
# Misc and spawning validation — 0.7.0

- Built against the installed SPT 4.1.6/BepInEx assemblies; only the pre-existing netstandard facade warning remains.
- 29 hotkey/input checks passed, including standalone flight modifiers, duplicate detection within action groups, preserving overlapping normal-gameplay bindings and default-off feature shortcuts.
- The installed user config.json and reference example both deserialize and parse with all 22 actions. The installed file was not modified.
- Stack-quantity tests passed for nonstackable items, ammo remainders, the 100-object boundary, large currency stacks, integer overflow and conservation of units across a range of quantities (761 assertions).
- Inspected native GameWorld.ThrowItem / LootItem.Init: they create an item owner and register world loot. Spawning uses native factory IDs, asset pools and one stack per frame, with raid/player/generation guards and cancellation.
- Inspected LocalGame.Stop and its base raid-end implementation. Extraction calls that native path after restoring temporary state; it does not simulate an extraction by changing a label or teleporting.
- Confirmed input-axis indices against EAxis: movement axes 0/1 are cleared during no-clip while turn/look axes remain available. Gravity suppression is scoped to the exact local MovementContext; controller collision/enable state is captured and restored.
- Flash hooks compare the affected components to the local main camera's EffectsController. Camera overrides and renderer enable states are captured/restored. Eye-burn clearing occurs on activation, not every frame.
- Scene queries exist only in door/extraction button actions. Catalog indexing and search are bounded and only run while the Spawning tab is open. Unity creation/registration runs on the main thread after task polling.
- Panic, world/player changes, extraction and shutdown reset Misc toggles and cancel future item stacks. Existing ESP, target logic, RCS and health math were not changed.

Live raid validation is pending: camera rendering, movement behaviour, door interaction, asset availability, loot pickup, FIR persistence and successful raid-end saving need an in-game test. These checks do not certify frame times or compatibility with every other mod. Prior validation follows.

---
# Combat-tool validation — 0.6.0

- Built against installed SPT 4.1.6/BepInEx assemblies.
- Fifteen new math checks passed: 0/partial/100% RCS, signed and clamped impulses, health percentage preservation, boost removal, multiplier changes, destroyed/invalid body values, export normalization.
- Inspected recoil dispatch: RecoilProcessBase and NewRotationRecoilProcess define distinct AddAccelerationLimitless implementations. Prefix guards identify only the local player's current recoil springs.
- Demigod snapshots actual runtime maxima, re-resolves HealthValue objects after full restoration, restores baseline maxima and normalizes the normal BaseHealthController Store result.
- Checked ValueInfo and BodyPartInfo are reference types, so serialized-result adjustments affect the exported health object.
- RCS has separate per-mode bindings and a visible section in each aim tab. Demigod is a Player practice control reset by the practice/Panic lifecycle.

Native hook execution, recoil-axis perception, live HUD updates, profile export compatibility and raid-end cleanup still need in-game validation. The existing compiler facade warning remains. Prior validation follows.

---

# Tooltip and Player validation — 0.5.0

- Compiled against installed SPT 4.1.6/BepInEx assemblies.
- Twelve tooltip geometry checks passed: normal size, reduced/enlarged scale, scrolling, clipped labels and edge boundaries.
- Verified the compiled code no longer calls GUI.get_tooltip; hover state updates on repaint and tooltip drawing occurs last inside the menu layer.
- Checked the game's full-health restoration, stamina fields and malfunction method. GetMalfunctionState has seven arguments with the expected by-reference source argument.
- Verified malfunction prevention calls the living-local-player scope guard and compares the controller to the exact held firearm instance.
- Practice toggles start/reset off; Panic and plugin shutdown reset them. No repeated scene searches added.
- Update ZIP preserves installed configuration and JSON files.

Live tooltip rendering/cursor scaling, stamina, health effects, malfunction prevention and raid-end reset remain to be verified in-game. The existing netstandard facade compiler warning remains. Previous validation follows.

---

# Maintenance validation — 0.4.1

Built against installed SPT 4.1.6. Compiled-code checks confirm EquipmentText, EquipmentDetailsAllowed and ArmourName are removed and no Gear tab remains. Equipment configuration binding and background reads are removed. Existing ESP/aim policy code is retained. This build has not been raid-tested. The existing facade-version warning remains.

---

# ESP validation — 0.4.0

- Compiled against installed SPT 4.1.6 and bundled BepInEx.
- 30 new ESP policy checks passed: role/faction/friendly classification; boss precedence; visible-only/hidden-only and unknown-result behaviour; conditional equipment detail rules.
- Verified integrated Body ESP, hidden-only checkbox and simulated preview in the compiled UI, with no standalone Bodies tab.
- Verified ESP visibility flags are absent from aim Candidate/PointAllowed methods.
- Verified no visibility calls in enemy drawing and no Unity scene-search regression.
- Verified presets do not touch enemy/loot/body master enables, visibility filters or aim mode/enable.
- Inspected bounded visibility sampling: at most two enemies per frame, up to three sample rays per enemy.
- Update ZIP excludes installed configuration replacements.

In-game rendering, occlusion accuracy, overlay placement, icon readability, preview interaction, body filtering and live performance are pending a raid test. The existing netstandard facade warning remains. Prior checks follow.

---

# Profile and contrast validation — 0.3.2

- Built against the installed SPT 4.1.6 and BepInEx assemblies.
- 17 new aim-profile checks passed: gentle/strong defaults, visibility enabled in both, preservation of activation/filters/exclusions, correction boundaries, gradual legit turns and immediate ninety-degree snap correction.
- Checked all 23 aim settings are bound separately for the two profiles. Runtime field references select a single profile; the shared master enable and F8 hotkey remain intact.
- Compiled GUI state inspection confirms all eight field/button style states are explicitly configured. Dark text fields isolate background/content tint and selection/caret colours from inherited GUI styling.
- No scene-search regression; native EFT aiming retained. Very wide FOV avoids singular circle projection.
- Checked the update ZIP contains no installed .cfg or config.json replacement.

Live GUI contrast, profile persistence and end-to-end mode activation have not been tested in a running raid. The existing netstandard facade compiler warning remains. Earlier validation follows.

---

# UI validation — 0.3.1

- Compiled successfully against installed SPT 4.1.6/BepInEx assemblies.
- Verified exact feature tooltip text: Aimbot only aims at visible targets.
- Checked Harmony hook targets against the installed GamePlayerOwner: CanTranslateCommand and TranslateAxes. Release commands are allowed; input blocking is limited to the local player while the custom window is open and its closing frame.
- Inspected the compiled assembly: native EFT aiming retained, no scene-search regression. The existing gameplay/preset/hotkey policy code is unchanged from the 0.3.0 checks listed below.
- Reviewed numeric/colour controls so opening the menu does not quantize stored values. Only explicit text edits or slider changes update them.
- Update ZIP preserves installed .cfg and config.json files.

Live UI rendering, scaled mouse hit testing, tooltip placement, input/cursor restoration and F12 transfer remain to be verified in-game. No live-game installation was performed during preparation. The existing netstandard facade warning remains.

---

# Validation — 0.3.0

- Compiled successfully against the installed SPT 4.1.6 assemblies and bundled BepInEx 5.
- 23 hotkey parsing/input checks passed against the current Hotkeys.cs, with simulated input and the game's KeyCode definitions.
- 14 aim activation/turn checks passed against the current AimLogic.cs.
- 30 feature-policy checks passed for presets, highlight bypass rules, exact enemy exclusions, taxonomy roots, switch-delay timing and correction boundaries.
- A later repeat invocation of the feature-policy executable was blocked by Windows Application Control. The initial successful run used the same feature-policy and aim-policy logic. No attempt was made to bypass that control.
- Binary inspection confirmed version 0.3.0, the native EFT Player.Rotate call, no Unity scene searches, and no direct main-loop file polling.
- JSON example parses correctly. The installed JSON was read for compatibility context and was not modified. Missing new hotkey fields retain their None initialisers.
- Update archive contains the replacement plugin and documentation/examples only; no installed .cfg or config.json file.

The existing compiler warning about the game's Newtonsoft.Json netstandard facade remains. These checks do not execute Unity, certify live frame times, or verify the quest/wishlist/corpse/equipment UI in a raid. In-game validation is pending.










