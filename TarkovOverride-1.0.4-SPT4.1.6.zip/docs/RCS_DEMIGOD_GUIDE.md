# Recoil control and Demigod

## RCS in Legit Aim and Rage Aim
Scroll down the right-hand column of either aim tab to **RCS / RECOIL CONTROL**. Each mode saves its own toggle and sliders:

- **RCS enabled:** applies the selected mode's recoil settings while that mode's master enable is on. It does not need an enemy target or target lock.
- **Vertical reduction (%):** reduces pitch impulses and vertical weapon-position impulses.
- **Horizontal reduction (%):** reduces yaw impulses and sideways weapon-position impulses.
- **Kickback reduction (%):** reduces rearward weapon-position impulses.
- **RCS right mouse only:** require right mouse held. Defaults on for Legit and off for Rage.

All sliders run from 0 to 100. Zero leaves that component unchanged; 50 retains half its new impulse; 100 cancels its new impulses. Existing spring motion can finish, and unrelated sway, animations, dispersion, overheating behaviour and camera roll are not removed.

RCS defaults OFF in both profiles. Suggested starting defaults are already stored: Legit 40% vertical / 25% horizontal / 15% kickback; Rage 100% for all three. Enable the desired aim mode at the top of its tab, then enable that profile's RCS. Browsing or editing an inactive profile does not activate it. If aiming is disabled with F8 or Panic, RCS stops too. No new hotkeys or automatic firing are added.

The hook scales recoil impulses only when their spring instance belongs to your local player's current recoil effect. Bots and global weapon templates are not changed. Both the base and current new-rotation recoil implementations are covered; no per-frame camera-counterrotation is added to fight the aimbot.

## Demigod in Player
**Demigod** increases each body part's maximum and current health using **Health multiplier**, adjustable from 1× to 100× with a default of 5×. Health percentage is preserved. For example, a part at half health remains at half health after scaling.

This is not invulnerability or continuous healing. Destroyed parts remain destroyed; scripted deaths and other game rules still apply. The existing Restore Health action can be used separately. The Player status panel shows current total health and its maximum.

Changing the multiplier recalculates from the captured original maximum rather than compounding boosts. Turning Demigod off restores original maxima and preserves the remaining health percentage. Panic, raid/player changes and plugin shutdown also restore health values and disable the toggle. It starts OFF on startup and between raids, while your chosen multiplier is remembered.

The health exporter is hooked to normalize the local controller's stored health to the captured original maxima. This prevents the boost itself from becoming a permanent base-health change through the normal Store path. A missing normalization hook disables Demigod instead of allowing an untracked boost. Other mods that replace or bypass health serialization can require additional compatibility work.

Full health restoration replaces the game's HealthValue objects. The cleanup resolves the current objects before restoring maxima, so using Restore Health does not intentionally leave boosted objects behind.