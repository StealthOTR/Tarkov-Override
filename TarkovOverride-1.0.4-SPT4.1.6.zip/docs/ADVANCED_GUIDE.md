# Equipment and raid tools — 0.8.1

## Player tab

Repair equipped gear is a one-shot action in Recovery actions. It repairs equipped primary weapons, pistol, armour, helmet, face/eye/ear gear and fitted attachment/plate slots. It does not traverse cargo grids, so loose items in bags or rigs are excluded. Restore maximum durability (on by default) also restores maximum durability to at least the template value; disable it to repair only up to the existing maximum. Repairs use no repair kit or money and persist with normal raid inventory saving. They are not undone by Panic.

Infinite medical supplies preserves the charges of your own medical items and prevents their native medical-use removal. Normal treatment time and effects remain. It covers local ActiveHealthController medical consumption, including medical items removed after use; it does not protect food/drinks or refill already empty items. Disabling it resumes normal consumption. Other mods with separate consumption paths may need additional support.

No weight penalties feeds zero effective weight into your native physical weight calculation. Inventory weight and item weights stay accurate. Weight-dependent movement, inertia and stamina parameters are recalculated normally using the zero input; gear's own armour/ergonomics penalties and unrelated stamina drain remain. Switching off recalculates using actual carried weight. Bots' weight inputs are unchanged.

Adjustable fire rate overrides the held local weapon's requested cadence and semi-auto cooldown. Use Fire rate RPM (60–2000). Automatic-fire intervals update while the weapon is held; disabling restores native timing. The native heat multiplier remains. Weapon animations, bolt cycling, trigger behaviour and malfunctions can still limit actual firing. It does not add automatic fire modes or fire for you, and does not edit shared weapon templates.

## Misc tab

Extended interaction range has its own toggle and Interaction distance slider (1–30 m). It changes the local loot/door ray distance and its validation while retaining native obstruction checks. It does not reach through walls or extend scripted vehicle, NPC/trader or special interaction systems. Shared hard-setting values are not edited; the override is limited to the local interaction query.

Always-available extractions makes normal exits for your faction available regardless of spawn point, payment, equipment/backpack, power, cooperation or manual-activation requirements. It bypasses the local requirement callbacks, enables the points and temporarily uses individual extraction mode. Normal extraction durations remain unchanged. Secret exits, transit zones and other scripted systems are excluded. It does not move vehicles or operate map machinery visually.

The toggle lives beside Instant extraction in Misc. If you enabled it while already standing in an unavailable zone, step out and re-enter. Switching off cancels the local override extraction and restores captured status, mode, activation and start-time state. Because these are captured states, switching off after a timed exit's schedule changed may not reproduce its current world-script state; the next raid initializes normally. The existing Instant extraction button still ends the raid immediately through the normal local raid-end flow.

## Nearby enemy alerts in ESP

Nearby enemy alerts works independently of the enemy ESP master toggle. The top-screen warning shows the number of living AI within Alert radius (5–200 m), the nearest enemy type/distance and a rough camera-relative direction. Boss labels retain their boss names. Matching nonempty group IDs are excluded. Other mods may define alliances without matching group IDs, so this is not a complete hostility detector.

Alert sound is optional and defaults off. Its volume and cooldown are adjustable. A five-metre re-entry margin prevents repeated tones when an enemy moves around the radius boundary. Checks run four times per second without visibility rays. The visual is hidden while normal gameplay overlays are suppressed by menus; the raid itself is not paused.

## Hotkeys and reset behaviour

Grenade trajectory preview has been removed, including its simulation work. An old ToggleGrenadePreview property is accepted for JSON compatibility and ignored.

All new optional bindings default to None and are editable through config.json or typed entries in Keys:

- ToggleInfiniteMedical
- ToggleNoWeight
- ToggleInteractionRange
- ToggleFireRate
- ToggleEnemyAlerts
- ToggleAvailableExtractions
- RepairEquippedGear

Existing JSON files load unchanged; missing fields use defaults. Saving in Keys writes them alongside your existing choices. No BepInEx key capture is used.

New feature toggles start off and reset on Panic, raid/player changes and shutdown. Slider values, colours and sound preferences remain saved. If a required hook fails to load, its control is disabled and the BepInEx log records the reason.