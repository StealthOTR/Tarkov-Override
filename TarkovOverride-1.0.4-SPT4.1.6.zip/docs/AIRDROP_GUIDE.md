# Manual airdrop — 0.8.2

Open Misc and press Request airdrop in the Supply Drop section. It calls the native solo SPT plane/crate system with normal SPT airdrop loot. It does not create an empty decoration or teleport a crate to your feet.

The button is enabled only while alive in a raid, with a ClientGameWorld, an initialized native server airdrop manager, active map drop points and native airdrops enabled for that raid. Unsupported maps, disabled managers and exhausted drop points show an explanation. Availability is detected from the current raid rather than a hardcoded map list.

A request selects a native map drop point. Watch and listen for the aircraft; normal flight and crate descent take time. The crate is not guaranteed to land near your player. Loot and flight behaviour remain subject to your SPT configuration and other airdrop mods.

The button has a 60-second cooldown to prevent repeated clicks. Its message confirms that the native request was made, not that the crate has already landed. Once requested, the aircraft and crate are managed by the game; closing the menu or pressing Panic does not remove them. A new raid resets the request cooldown.

No extra hotkey, frame-loop scan or trajectory physics simulation was added. The game still performs its normal airdrop asset loading, flight and landing work when requested.

Built against installed SPT 4.1.6. Native ClientGameWorld.InitAirdrop dispatch, ServerAirdropManager support checks and the plane spawn path were inspected. Live plane arrival, loot generation and crate pickup still need a raid test.

Vampire Mode remains on the planned feature list and is not included in this update.
