# Player practice tools — 0.5.0

The Player tab provides local raid-practice controls. They start disabled on startup and reset off when the local player/world changes, the player dies or the raid ends. The existing Panic key disables the ongoing practice toggles as well as ESP/aim features.

## Practice toggles

- **Unlimited stamina:** keeps your body and arm stamina at their current maximum and clears stamina overuse. It does not edit character skills or global stamina templates. Other stamina mods may overlap with it.
- **Prevent malfunctions:** prevents new malfunction outcomes on your currently held local-player firearm. It does not change bots, global weapon templates, durability, ammunition or an existing jam. If its hook cannot load, this control is disabled and the reason is logged.

The compact-menu toggles are disabled outside a raid with a living local player. Practice flags are not intended to persist as an always-on character modification.

## Recovery buttons

- **Restore health:** requests the game's full-health restoration for your local living player. This is a one-shot action, not god mode, continuous regeneration or resurrection. It does not promise to replenish energy/hydration or undo every scripted raid condition.
- **Refill stamina once:** restores body and arm stamina once without enabling unlimited stamina.

Actions report success/failure in the Player tab. The game world continues while the menu is open.

## Tooltip fix

Tooltips now use explicit mouse hit-testing against the feature label/control, including menu scaling, window position, scrolling and viewport clipping. Hover results are no longer overwritten by GUI.tooltip. The delay advances on repaint events only, and the tooltip is drawn last inside the menu layer after the scrolling clips close.

Hover a feature name for approximately 0.3 seconds. For example, Visible Targets Only still says **Aimbot only aims at visible targets**. Recovery buttons also have help text. Twelve automated geometry checks passed for ordinary/scaled/scrolled/clipped label hit-testing.

## Install and test

Close the game, extract the update's BepInEx folder into SPT and replace the existing DLL. Your JSON hotkeys and other settings remain intact; no new hotkeys are added for these actions. The tabs are ESP, Loot, Legit Aim, Rage Aim, Player and Keys. F12 remains available.

Built against installed SPT 4.1.6. Native health/stamina APIs and the held-firearm malfunction hook were checked against that build. Hook guards require the living local player and the exact held firearm controller. No repeated scene searches were added.

This update has not been tested in a live raid. Please verify tooltip display after scrolling/scaling, practice toggle reset, stamina, health restoration and prevention of new malfunctions. The existing netstandard facade compiler warning remains. Neither successful compilation nor geometry checks prove Unity runtime behaviour.
