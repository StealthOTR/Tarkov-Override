# Rage tracking and ballistics — 1.0.3

For the first test, select Rage Aim, enable Instant lock and Strict Head Targeting, and leave Movement prediction and Bullet drop compensation off. Check the selected-target marker and ADS behaviour with both ordinary and magnified sights.

Strict Head forces the runtime selection to Head regardless of a saved Chest/Pelvis/Nearest setting. Its inactive target-point and fallback controls are greyed out. Visibility, range, target-type and exclusion checks still apply. A missing or blocked head is skipped; aiming at body alternatives is not allowed in strict mode.

Head tracking now resolves a head transform from the rendered PlayerBody skeleton, cached per enemy and skeleton. HumanHead (including prefixed names) and exact Head are accepted; neck and head-camera names are excluded. If that model skeleton has no matching head, the original native Head transform is cached instead. Collider-centre alternatives are not used. A replacement skeleton or destroyed transform causes a fresh resolution. No scene/hierarchy search is performed each frame.

Rage Instant lock now computes its correction from MovementContext.LookDirection, the native yaw/pitch state, instead of the rendered camera forward vector. This removes a potential feedback mismatch between logical rotation and a delayed or animated ADS camera. It still applies rotation through the existing native Player.Rotate path.

Movement prediction and Bullet drop compensation are separate Rage-only options, default off. Prediction reads the target's native velocity and the held weapon's current ammunition/muzzle speed, including the weapon's velocity factor. Speed is cached briefly and refreshed on weapon/ammo changes. Prediction strength scales target velocity; Maximum flight prediction seconds bounds the solution. No valid solution means no compensation that frame, not a guessed extreme offset.

The analytic solution estimates movement intercept and refines gravity compensation without physics casts or simulated projectiles. It does not fully reproduce native air drag, sight zeroing, spread or every ammo/weapon modifier. It should be evaluated as an optional estimate, especially at long range, not a guaranteed hit system.

The selected-target marker remains on the enemy's current anatomical head when prediction leads ahead or drop compensation raises the aim solution. Aim status identifies the head source and active lead/drop estimate. This separates target selection from the compensated shot direction.