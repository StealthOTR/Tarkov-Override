# ESP revamp — 0.4.1

## ESP tab
ESP controls on the left and a separate **Body ESP** section on the right, below the live preview. Body ESP still has its own enable, range and refresh controls and can run with enemy ESP and loot ESP off.

### Living enemies
- Full boxes, corner brackets, or a small marker. New installations of this appearance setting default to corner brackets.
- Independent type filters and palettes for USEC, BEAR, SCAV, bosses, guards, raiders, rogues, cultists, Bloodhounds, infected, same-group friendlies and other AI.
- Boss names remain intact; Boss emphasis adds a diamond above them.
- Visible enemies use the full category colour; occluded enemies use Hidden brightness. Disable Colours by type to use your previous uniform enemy colour.
- Distant enemy markers replace distant boxes and suppress health/skeleton detail beyond the chosen Enemy detail range. Type/distance labels remain available.

**Visible only** and **Hidden enemies only** are mutually exclusive checkboxes. Hidden-only shows enemies when all sampled head/chest/pelvis rays are blocked. It affects living-enemy ESP only; it does not change Legit Aim, Rage Aim, Body ESP or loot visibility. If a manually edited configuration enables both, hidden-only takes precedence.

Visibility uses physics rays, not exact rendered-pixel analysis. Glass, foliage, modded colliders and partial cover can affect the result. Checks are limited to two on-screen enemies per frame, with up to three rays each. Unknown/stale results are omitted when a visibility filter is active, and a short update delay is possible while moving around cover. Drawing does not issue visibility raycasts.

Friendlies means a matching nonempty group ID. It does not identify every possible neutral relationship or modded alliance.

### Body ESP
Bodies have a diamond-with-cross symbol and a `[CORPSE]` label to distinguish them from living enemies. Their type filters and colours are independent of the living-enemy palette. Turn Body type colours off to use the old uniform corpse colour.

Type and boss identity are retained when observed alive during the raid. Unknown bodies use their faction as a fallback. Same-group identities also carry into body markers when known. Bodies are never aimbot targets, and searched bodies are not automatically hidden.

### Presets and preview
- **Simple:** corner brackets, type/distance, slim health bars, reduced distant details, no skeleton, compact loot.
- **Detailed:** full boxes, health, skeleton, and more verbose loot presentation.
- **Custom:** your own appearance settings. Editing watched appearance controls switches the selector to Custom.

Presets do not enable or disable the enemy/loot/body master switches, alter enemy type/visibility filters, or change aim profiles. They do change secondary appearance options, such as skeletons and loot presentation.

The **LIVE PREVIEW / SIMULATED** panel uses the same shape and colour settings as the overlay. Cycle its enemy type, visible/behind-cover sample, and enemy/body mode. It responds to relevant filters and appearance controls without needing a raid. It is simulated, not a live view of an actual enemy.

## Loot tab
- Category icons distinguish ammo, valuables, keys, medical items, attachments, weapons, equipment, provisions and barter items. Icons are generated once and cached.
- Highlight priority remains **quest first, wishlist second, ordinary loot third**, with nearest first within each priority. Compact displays preserve the highest-priority tag.
- With **Look to expand clusters** enabled, nearby labels collapse into an item count; looking toward the cluster reveals names, up to Expanded names. Remaining items show as +N nearby.
- **Distance detail** makes distant loose loot a small category marker. Full names appear within Loot name range or when looking toward it. Important quest/wishlist items keep a compact tag at distance.
- Turning grouping off restores individual markers. Existing category presets, custom category switches, text filters, refresh interval and label limit still apply.

Clusters count items admitted to the existing label budget, not every item in the entire map. Container markers indicate position only; contents are not inspected. Group layout updates ten times per second and label distances four times per second.

## Performance and validation
Registry scans remain limited to 32 loot/owner entries per frame; quest reads remain batched. Enemy equipment reads have been removed. There are no repeated Unity scene searches or main-loop filesystem polling. Visibility sampling adds bounded physics work.

Built against installed SPT 4.1.6. Thirty new ESP policy checks passed for type classification, visibility-filter behaviour and conditional equipment details. Compiled-code checks confirm aim-filter independence, integrated Body ESP, cached drawing and preset isolation from master switches.