# Changelog

## 1.0.0 — Tarkov Override release package

- Renamed the displayed mod and compact window to Tarkov Override.
- Added Author: StealthOTR beneath the persistent window title, outside all tabs.
- Updated assembly title, product, author/company credit and version metadata.
- Preserved plugin identity, installed DLL path and config locations for seamless upgrades.
- Prepared installation/removal instructions, feature guides, credits, known limitations and separate source package.
- Gameplay logic is unchanged from 0.8.3.

## 0.8.3

Fixed no-clip compatibility with SimpleCharacterController and improved controller-state restoration.

## 0.8.2

Added the native airdrop request button under Misc, gated by current-map support and a 60-second cooldown.

## 0.8.1

Removed grenade trajectory preview and its simulation work. Legacy JSON shortcut entries are accepted but ignored.

## 0.8.0

Added gear repair, infinite medical supplies, no weight penalties, interaction range, adjustable fire rate, nearby alerts and extraction overrides.

## Earlier development

Introduced ESP/loot tools, configurable aim profiles, the compact menu/tooltips, RCS, player practice tools, vision/no-clip, door/extraction actions and item spawning. See docs/VALIDATION.md for historical technical checks and their limits.
