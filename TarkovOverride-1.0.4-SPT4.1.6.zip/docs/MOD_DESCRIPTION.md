# Tarkov Override

**Author: StealthOTR**

**Your raid. Your rules.**

Take control of your single-player Tarkov experience with Tarkov Override—a configurable sandbox and practice toolkit that puts everything in one compact menu.

Track threats, find the loot you’re chasing, fine-tune your aim or build your ideal loadout mid-raid. Whether you’re learning a map, testing equipment or enjoying a little unrestricted chaos, Tarkov Override gives you the controls to play your way.

**See what matters**
Spot enemies with clear, customisable ESP, enemy-type labels, boss names, health bars and visibility filters. Find valuable loot with category presets, quest-item and wishlist highlighting, plus clutter controls that keep your screen readable. Independent corpse markers and nearby-enemy alerts help you stay aware of your surroundings.

***Build your own sandbox****
Spawn items during a raid, repair equipped weapons and armour, adjust fire rate, remove weight penalties and extend your interaction range. Player tools include health restoration, configurable Demigod health, unlimited stamina, infinite medical supplies and malfunction prevention.

Explore with no-clip, switch on night or thermal vision, and clear your view with No Flash and No Visor. Unlock nearby doors, override normal extraction requirements or request a real plane-delivered airdrop on supported maps.

**Easy to configure**
A compact, draggable menu keeps controls organised into tabs, with hover tooltips explaining each feature. Hotkeys support editable JSON bindings, and a Panic key quickly disables active tools. Many temporary player and world overrides reset between raids.

**Learn the maps. Test your limits. Rewrite the raid.**

Author: StealthOTR
Requires: SPT 4.1.6
Solo only: Fika is not supported.

Some features depend on native map support. Airdrops use normal flight time, weapons spawn as bare templates, and special or scripted extractions are outside the normal extraction override. See the included guides for details.