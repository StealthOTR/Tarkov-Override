# Tarkov Override

**Author: StealthOTR**

A configurable sandbox and practice toolkit for solo SPT 4.1.6.

Tarkov Override brings enemy/body and loot ESP, separate Legit Aim and Rage Aim profiles, recoil controls, player practice tools, vision modes, movement and interaction overrides, item spawning and native airdrop requests into a compact in-game window. Hover feature names for help and change hotkeys through JSON text entry.

## Highlights

- Type-based enemy markers with boss names, visibility filters and independent body ESP.
- Loot presets, quest/wishlist highlights and clutter controls.
- Separate aim profiles, target exclusions, switch delay and RCS sliders.
- Health/stamina tools, equipment repair, medical supplies, weight and fire-rate controls.
- Night/thermal vision, No Flash, No Visor, no-clip and extended interaction range.
- Door/extraction controls, native airdrop requests and searchable in-raid item spawning.
- Nearby enemy warnings with optional sound.

## Compatibility and installation

Requires exactly SPT 4.1.6. Solo only; Fika is not supported. Close the game, merge the archive's BepInEx folder into SPT and replace the existing plugin DLL. Insert opens the menu by default. Existing SPT Field Toolkit settings and JSON bindings carry over because internal identity and installation paths are retained.

Read the included installation guide and known limitations. Some features require map/native support; airdrops take normal flight time. Grenade trajectory preview is removed. Vampire Mode is planned, not included.

Publication draft: add current screenshots, selected licensing terms and support details, and complete the release checklist before submission.
