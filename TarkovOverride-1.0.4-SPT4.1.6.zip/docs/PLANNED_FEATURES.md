# Planned features
- Vampire Mode: regain a configurable amount of health from damage dealt or kills. Planned only; not included in the current build.

