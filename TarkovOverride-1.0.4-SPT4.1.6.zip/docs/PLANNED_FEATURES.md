# Planned features

- Vampire Mode: regain a configurable amount of health from damage dealt or kills. Planned only; not included in the current build.

# Implemented request

- Request airdrop button in Misc: included in 0.8.2. Uses the native plane/crate system on supported, enabled maps with active drop points.
