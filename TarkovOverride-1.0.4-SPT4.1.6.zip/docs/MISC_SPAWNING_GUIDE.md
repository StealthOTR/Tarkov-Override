# Misc and Item Spawning — 0.7.0

## Misc
New toggles act during a raid with a living local player. They reset at startup, player/world changes, raid end, shutdown and Panic. Slider values remain saved.

Night vision and Thermal vision use native main-camera components. Enabling one disables the other override. Disabling both restores the captured camera states. These controls do not edit equipped devices. Camera changes restore old components and capture new ones. If you change equipped goggles during an override, switch the override off and toggle the equipped device normally to synchronize its current state.

No flash disables the main camera's flash screen and eye-burn rendering, clears existing afterimages and suppresses new flash impulses. It does not remove grenade damage, sound effects or effects on bots. No visor disables visor screen rendering while retaining the item's armour behaviour. Renderer enable states are restored on switch-off.

No-clip disables the local movement controller's collision, normal movement and gravity, and moves the player with native teleport updates. Mouse look remains available. Menus, inventory, focus loss and pause stop flight input. Speed and boost are adjustable. Defaults are W/S/A/D, Space up, C down, LeftShift boost; change them in Keys or config.json. No-clip does not give damage immunity. Return to an open spot near ground level before disabling it; it does not automatically find a safe landing.

Unlock nearest door affects a locked normal Door within four metres. Unlock nearby doors uses the Door radius slider (1–50 m). Doors become shut/unlocked. These buttons do not operate power switches, scripted gates or machinery. Scene queries occur only when buttons are pressed.

Instant extraction ends the raid from your current position. Click once to arm and again within five seconds to confirm. It requests Survived through native LocalGame.Stop with zero extraction delay; the normal fade/results/save process still takes place. It does not teleport or run an exit countdown. Temporary health boosts, camera overrides, no-clip and pending spawns reset before raid saving. Final raid processing remains subject to SPT and other installed mods.

## Spawning
1. Open Spawning during a raid.
2. Search localized names or template IDs. Catalog indexing runs in batches while this tab is open. Up to 100 matches appear; narrow your search as needed.
3. Click an item, or paste its template ID in the right column.
4. Enter quantity and choose Found in raid status.
5. Click Spawn near player. Wait for completion, close the window and pick up the loot normally.

The spawner loads native assets into raid pools, creates fresh IDs and registers world loot through GameWorld.ThrowItem. Unity object work stays on the main thread. Asset loading is asynchronous; stacks are created one per frame. No mail, direct stash edits or server mod are involved.

Quantity means total units: 180 rounds with a 60-round stack maximum become three stacks. Requests accept 1–100000 units but at most 100 physical stacks. Items appear in a small grid roughly a metre in front of the player, above ground so they can settle. Stand near clear ground. The first asset load may still cause game-side loading work.

The catalog includes item templates with world prefabs, including compatible modded templates, and excludes abstract category nodes. Weapons spawn as bare templates; parts can be spawned separately. Some special/modded items may fail native creation or lack usable world loot behaviour. Status and BepInEx logs report failures. Already spawned items remain if a later stack fails.

Cancel remaining spawns, Panic, raid/player changes, extraction and shutdown stop future stacks and cancel pending loading. They do not delete existing loot. Collected items follow normal inventory capacity, pickup and raid saving. Choose Found in raid before spawning if desired.

## New JSON bindings
ToggleNightVision, ToggleThermalVision, ToggleNoFlash, ToggleNoVisor and ToggleNoClip default to None.

Movement fields are NoClipForward, NoClipBack, NoClipLeft, NoClipRight, NoClipUp, NoClipDown and NoClipBoost. Standalone modifiers such as LeftShift are allowed for these held bindings. Use Keys and Save hotkeys to JSON to persist defaults alongside your current bindings.
