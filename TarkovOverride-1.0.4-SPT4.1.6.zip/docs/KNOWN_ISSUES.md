# Known limitations — 1.0.0

- Exactly SPT 4.1.6 is supported. Fika is explicitly disabled. Other mod combinations are not exhaustively tested.
- Automated checks do not replace live raid, profile saving and cross-map validation. See VALIDATION.md for actual evidence.
- Quest highlights match incomplete find/handover item templates and do not certify every quest restriction. Container contents are not scanned.
- Visibility sampling is bounded and can lag or misclassify unusual geometry. Group IDs are used for friendly exclusions and may not represent modded alliances.
- No-clip must be disabled in clear space near the ground. It does not provide damage immunity or find a safe landing point automatically.
- Camera overrides restore captured states. Changing equipped vision devices during an override may require toggling the device normally afterwards.
- Fire-rate settings request a cadence; native animation, heat, bolt cycling and malfunctions may limit observed firing.
- Extraction overrides cover normal faction exits, not secret/transit/scripted zones. Restoring captured states does not reconstruct world-script schedule changes during the override.
- Airdrops require an enabled native manager and active map points. Normal flight, loot generation and map selection remain native; landing near the player is not guaranteed.
- Item spawning uses actual native templates. Weapons are bare templates; unusual modded/special templates may not create usable loot. Requests are limited to 100 physical stacks. First asset loading can still create game-side loading work.
